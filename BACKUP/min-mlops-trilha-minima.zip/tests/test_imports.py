def test_imports():
    import transformers, datasets, pytorch_lightning, torchmetrics, hydra
